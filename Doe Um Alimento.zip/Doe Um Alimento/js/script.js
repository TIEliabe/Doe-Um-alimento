// ==========================================
// MENU MOBILE
// ==========================================

const menuButton = document.getElementById("menuButton");
const menu = document.getElementById("menu");

if (menuButton && menu) {

    menuButton.addEventListener("click", function () {

        menu.classList.toggle("open");

    });


    const links = menu.querySelectorAll("a");

    links.forEach(function (link) {

        link.addEventListener("click", function () {

            menu.classList.remove("open");

        });

    });

}



// ==========================================
// CONTADORES
// ==========================================

const counters =
    document.querySelectorAll(".counter");


function animateCounter(element) {

    const target =
        Number(element.dataset.target);

    const duration = 1800;

    const startTime =
        performance.now();


    function update(time) {

        const elapsed =
            time - startTime;

        const progress =
            Math.min(elapsed / duration, 1);


        // Suaviza o movimento do número
        const ease =
            1 - Math.pow(1 - progress, 3);


        const value =
            Math.floor(ease * target);


        element.textContent =
            value.toLocaleString("pt-BR");


        if (progress < 1) {

            requestAnimationFrame(update);

        } else {

            element.textContent =
                target.toLocaleString("pt-BR");

        }

    }


    requestAnimationFrame(update);

}



// ==========================================
// ATIVAR CONTADORES QUANDO APARECEREM
// ==========================================

if (counters.length > 0) {

    const counterObserver =
        new IntersectionObserver(

            function (entries, observer) {

                entries.forEach(function (entry) {

                    if (entry.isIntersecting) {

                        animateCounter(
                            entry.target
                        );

                        observer.unobserve(
                            entry.target
                        );

                    }

                });

            },

            {
                threshold: 0.3
            }

        );


    counters.forEach(function (counter) {

        counterObserver.observe(counter);

    });

}



// ==========================================
// CONTADOR PRINCIPAL DO HERO
// ==========================================

const foodCounter =
    document.getElementById("foodCounter");


if (foodCounter) {

    const target = 0;

    const duration = 1800;

    const startTime =
        performance.now();


    function updateFoodCounter(time) {

        const elapsed =
            time - startTime;

        const progress =
            Math.min(
                elapsed / duration,
                1
            );


        const ease =
            1 - Math.pow(1 - progress, 3);


        const value =
            Math.floor(
                ease * target
            );


        foodCounter.textContent =
            value.toLocaleString("pt-BR");


        if (progress < 1) {

            requestAnimationFrame(
                updateFoodCounter
            );

        } else {

            foodCounter.textContent =
                target.toLocaleString("pt-BR");

        }

    }


    requestAnimationFrame(
        updateFoodCounter
    );

}



// ==========================================
// ANIMAÇÃO DOS ELEMENTOS AO ROLAR
// ==========================================

// Elementos que queremos animar
const animatedElements = [

    ".section-title",
    ".step",
    ".account-card",
    ".cta-box",
    ".about",
    ".stat"

];


// Adiciona a classe animate
animatedElements.forEach(function (selector) {

    const elements =
        document.querySelectorAll(selector);


    elements.forEach(function (element) {

        element.classList.add("animate");

    });

});



// Observa os elementos
const animationObserver =
    new IntersectionObserver(

        function (entries, observer) {

            entries.forEach(function (entry) {

                if (entry.isIntersecting) {

                    entry.target.classList.add("show");

                    observer.unobserve(
                        entry.target
                    );

                }

            });

        },

        {
            threshold: 0.15
        }

    );


// Começa a observar
document
    .querySelectorAll(".animate")
    .forEach(function (element) {

        animationObserver.observe(element);

    });



// ==========================================
// ANIMAÇÃO ESCALONADA DOS CARDS
// ==========================================

document
    .querySelectorAll(".step")
    .forEach(function (card, index) {

        card.style.transitionDelay =
            `${index * 0.15}s`;

    });


document
    .querySelectorAll(".account-card")
    .forEach(function (card, index) {

        card.style.transitionDelay =
            `${index * 0.15}s`;

    });



// ==========================================
// ANO AUTOMÁTICO DO RODAPÉ
// ==========================================

const year =
    document.getElementById("year");


if (year) {

    year.textContent =
        new Date().getFullYear();

}