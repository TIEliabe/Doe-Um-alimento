// ==========================================
// ELEMENTOS PRINCIPAIS
// ==========================================

const form =
    document.getElementById("registerForm");

const senha =
    document.getElementById("senha");

const confirmarSenha =
    document.getElementById("confirmarSenha");

const strengthBar =
    document.getElementById("strengthBar");

const passwordMessage =
    document.getElementById("passwordMessage");

const formMessage =
    document.getElementById("formMessage");


// ==========================================
// TIPO DE CONTA
// ==========================================

const tipoConta =
    document.querySelectorAll(
        'input[name="tipoConta"]'
    );

const consumerFields =
    document.getElementById("consumerFields");

const companyFields =
    document.getElementById("companyFields");


// ==========================================
// CAMPOS
// ==========================================

const nome =
    document.getElementById("nome");

const cpf =
    document.getElementById("cpf");

const razaoSocial =
    document.getElementById("razaoSocial");

const nomeFantasia =
    document.getElementById("nomeFantasia");

const cnpj =
    document.getElementById("cnpj");

const endereco =
    document.getElementById("endereco");

const cep =
    document.getElementById("cep");

const cidade =
    document.getElementById("cidade");

const estado =
    document.getElementById("estado");

const telefone =
    document.getElementById("telefone");


// ==========================================
// MOSTRAR CAMPOS DO TIPO DE CONTA
// ==========================================

function atualizarTipoConta() {

    const selecionado =
        document.querySelector(
            'input[name="tipoConta"]:checked'
        );


    if (!selecionado) {
        return;
    }


    if (selecionado.value === "empresa") {

        // Esconde consumidor
        consumerFields.classList.add("hidden");

        // Mostra empresa
        companyFields.classList.remove("hidden");


        // Campos de consumidor deixam de ser obrigatórios
        nome.required = false;
        cpf.required = false;


        // Campos de empresa passam a ser obrigatórios
        razaoSocial.required = true;
        nomeFantasia.required = true;
        cnpj.required = true;
        endereco.required = true;
        cep.required = true;
        cidade.required = true;
        estado.required = true;
        telefone.required = true;


    } else {

        // Mostra consumidor
        consumerFields.classList.remove("hidden");

        // Esconde empresa
        companyFields.classList.add("hidden");


        // Campos do consumidor obrigatórios
        nome.required = true;
        cpf.required = true;


        // Campos da empresa deixam de ser obrigatórios
        razaoSocial.required = false;
        nomeFantasia.required = false;
        cnpj.required = false;
        endereco.required = false;
        cep.required = false;
        cidade.required = false;
        estado.required = false;
        telefone.required = false;

    }

}


// ==========================================
// CLIQUE CONSUMIDOR / EMPRESA
// ==========================================

tipoConta.forEach(function (radio) {

    radio.addEventListener(
        "change",
        atualizarTipoConta
    );

});


// Executa ao abrir a página
atualizarTipoConta();


// ==========================================
// MOSTRAR / ESCONDER SENHA
// ==========================================

const passwordButtons =
    document.querySelectorAll(".show-password");


passwordButtons.forEach(function (button) {

    button.addEventListener(
        "click",
        function () {

            const targetId =
                button.dataset.target;

            const input =
                document.getElementById(targetId);


            if (input.type === "password") {

                input.type = "text";

                button.textContent = "🙈";

            } else {

                input.type = "password";

                button.textContent = "👁";

            }

        }
    );

});


// ==========================================
// FORÇA DA SENHA
// ==========================================

senha.addEventListener(
    "input",
    function () {

        const value =
            senha.value;

        let strength = 0;


        if (value.length >= 8) {
            strength++;
        }


        if (/[A-Z]/.test(value)) {
            strength++;
        }


        if (/[0-9]/.test(value)) {
            strength++;
        }


        if (/[^A-Za-z0-9]/.test(value)) {
            strength++;
        }


        const widths = [
            "0%",
            "25%",
            "50%",
            "75%",
            "100%"
        ];


        strengthBar.style.width =
            widths[strength];


        if (value.length === 0) {

            passwordMessage.textContent =
                "Use pelo menos 8 caracteres.";

        } else if (strength <= 1) {

            passwordMessage.textContent =
                "Senha fraca.";

        } else if (strength === 2) {

            passwordMessage.textContent =
                "Senha média.";

        } else if (strength === 3) {

            passwordMessage.textContent =
                "Senha boa.";

        } else {

            passwordMessage.textContent =
                "Senha forte.";

        }

    }
);


// ==========================================
// CONFIRMAÇÃO DA SENHA
// ==========================================

confirmarSenha.addEventListener(
    "input",
    function () {

        const error =
            document.getElementById(
                "senhaError"
            );


        if (
            confirmarSenha.value &&
            confirmarSenha.value !== senha.value
        ) {

            error.textContent =
                "As senhas não são iguais.";

        } else {

            error.textContent =
                "";

        }

    }
);


// ==========================================
// MÁSCARA CPF
// ==========================================

cpf.addEventListener(
    "input",
    function () {

        let value =
            cpf.value.replace(/\D/g, "");


        value =
            value.substring(0, 11);


        value =
            value.replace(
                /(\d{3})(\d)/,
                "$1.$2"
            );


        value =
            value.replace(
                /(\d{3})(\d)/,
                "$1.$2"
            );


        value =
            value.replace(
                /(\d{3})(\d{1,2})$/,
                "$1-$2"
            );


        cpf.value =
            value;

    }
);


// ==========================================
// MÁSCARA CNPJ
// ==========================================

cnpj.addEventListener(
    "input",
    function () {

        let value =
            cnpj.value.replace(/\D/g, "");


        value =
            value.substring(0, 14);


        value =
            value.replace(
                /^(\d{2})(\d)/,
                "$1.$2"
            );


        value =
            value.replace(
                /^(\d{2})\.(\d{3})(\d)/,
                "$1.$2.$3"
            );


        value =
            value.replace(
                /\.(\d{3})(\d)/,
                ".$1/$2"
            );


        value =
            value.replace(
                /(\d{4})(\d{1,2})$/,
                "$1-$2"
            );


        cnpj.value =
            value;

    }
);


// ==========================================
// MÁSCARA TELEFONE
// ==========================================

telefone.addEventListener(
    "input",
    function () {

        let value =
            telefone.value.replace(/\D/g, "");


        value =
            value.substring(0, 11);


        if (value.length <= 10) {

            value =
                value.replace(
                    /(\d{2})(\d)/,
                    "($1) $2"
                );


            value =
                value.replace(
                    /(\d{4})(\d)/,
                    "$1-$2"
                );

        } else {

            value =
                value.replace(
                    /(\d{2})(\d)/,
                    "($1) $2"
                );


            value =
                value.replace(
                    /(\d{5})(\d)/,
                    "$1-$2"
                );

        }


        telefone.value =
            value;

    }
);


// ==========================================
// MÁSCARA CEP
// ==========================================

cep.addEventListener(
    "input",
    function () {

        let value =
            cep.value.replace(/\D/g, "");


        value =
            value.substring(0, 8);


        value =
            value.replace(
                /(\d{5})(\d)/,
                "$1-$2"
            );


        cep.value =
            value;

    }
);


// ==========================================
// ENVIO DO FORMULÁRIO
// ==========================================

form.addEventListener(
    "submit",
    function (event) {

        event.preventDefault();


        formMessage.textContent =
            "";


        // ======================================
        // TIPO DE CONTA
        // ======================================

        const tipoSelecionado =
            document.querySelector(
                'input[name="tipoConta"]:checked'
            );


        if (!tipoSelecionado) {

            formMessage.textContent =
                "Selecione o tipo de conta.";

            formMessage.style.color =
                "#c53d3d";

            return;

        }


        const tipo =
            tipoSelecionado.value;


        // ======================================
        // SENHA
        // ======================================

        if (senha.value.length < 8) {

            formMessage.textContent =
                "A senha precisa ter pelo menos 8 caracteres.";

            formMessage.style.color =
                "#c53d3d";

            senha.focus();

            return;

        }


        // ======================================
        // CONFIRMAÇÃO
        // ======================================

        if (
            senha.value !==
            confirmarSenha.value
        ) {

            formMessage.textContent =
                "As senhas não são iguais.";

            formMessage.style.color =
                "#c53d3d";

            confirmarSenha.focus();

            return;

        }


        // ======================================
        // TERMOS
        // ======================================

        const termos =
            document.getElementById("termos");


        if (!termos.checked) {

            formMessage.textContent =
                "Você precisa aceitar os Termos de Uso.";

            formMessage.style.color =
                "#c53d3d";

            return;

        }


        // ======================================
        // CONSUMIDOR
        // ======================================

        if (tipo === "consumidor") {


            const consumidor =
                {

                    tipo: "consumidor",

                    nome: nome.value,

                    cpf: cpf.value,

                    email: document.getElementById(
                        "email"
                    ).value

                };


            // Salva uma conta de demonstração
            localStorage.setItem(
                "contaDoeAlimento",
                JSON.stringify(consumidor)
            );


            formMessage.textContent =
                "Cadastro de consumidor realizado com sucesso!";

            formMessage.style.color =
                "#23733d";


            setTimeout(
                function () {

                    window.location.href =
                        "usuario.html";

                },
                800
            );


            return;

        }


        // ======================================
        // EMPRESA
        // ======================================

        if (tipo === "empresa") {


            const empresa =
                {

                    tipo: "empresa",

                    status: "pendente",

                    razaoSocial:
                        razaoSocial.value,

                    nomeFantasia:
                        nomeFantasia.value,

                    cnpj:
                        cnpj.value,

                    endereco:
                        endereco.value,

                    cep:
                        cep.value,

                    cidade:
                        cidade.value,

                    estado:
                        estado.value,

                    telefone:
                        telefone.value,

                    email:
                        document.getElementById(
                            "email"
                        ).value

                };


            // Salva a empresa como pendente
            localStorage.setItem(
                "empresaPendente",
                JSON.stringify(empresa)
            );


            formMessage.innerHTML =
                "Cadastro enviado com sucesso!<br>" +
                "Sua empresa está <strong>pendente de aprovação</strong> pelo administrador.";


            formMessage.style.color =
                "#765d16";


            // Não manda a empresa para cadastrar alimentos
            return;

        }

    }
);