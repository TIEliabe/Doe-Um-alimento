const form =
    document.getElementById("registerForm");

const senha =
    document.getElementById("senha");

const confirmarSenha =
    document.getElementById("confirmarSenha");

const strengthBar =
    document.getElementById("strengthBar");

const passwordMessage =
    document.getElementById("passwordMessage");


// ==========================================
// MOSTRAR / ESCONDER SENHA
// ==========================================

const passwordButtons =
    document.querySelectorAll(".show-password");

passwordButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        const targetId =
            button.dataset.target;

        const input =
            document.getElementById(targetId);

        if (input.type === "password") {

            input.type = "text";

            button.textContent = "🙈";

        } else {

            input.type = "password";

            button.textContent = "👁";

        }

    });

});


// ==========================================
// FORÇA DA SENHA
// ==========================================

senha.addEventListener("input", function () {

    const value = senha.value;

    let strength = 0;

    if (value.length >= 8) {
        strength++;
    }

    if (/[A-Z]/.test(value)) {
        strength++;
    }

    if (/[0-9]/.test(value)) {
        strength++;
    }

    if (/[^A-Za-z0-9]/.test(value)) {
        strength++;
    }

    const widths = [
        "0%",
        "25%",
        "50%",
        "75%",
        "100%"
    ];

    strengthBar.style.width =
        widths[strength];

    if (value.length === 0) {

        passwordMessage.textContent =
            "Use pelo menos 8 caracteres.";

    } else if (strength <= 1) {

        passwordMessage.textContent =
            "Senha fraca.";

    } else if (strength === 2) {

        passwordMessage.textContent =
            "Senha média.";

    } else if (strength === 3) {

        passwordMessage.textContent =
            "Senha boa.";

    } else {

        passwordMessage.textContent =
            "Senha forte.";

    }

});


// ==========================================
// CONFIRMAÇÃO DA SENHA
// ==========================================

confirmarSenha.addEventListener(
    "input",
    function () {

        const error =
            document.getElementById(
                "senhaError"
            );

        if (
            confirmarSenha.value &&
            confirmarSenha.value !== senha.value
        ) {

            error.textContent =
                "As senhas não são iguais.";

        } else {

            error.textContent = "";

        }

    }
);


// ==========================================
// MÁSCARA CPF
// ==========================================

const cpf =
    document.getElementById("cpf");

cpf.addEventListener("input", function () {

    let value =
        cpf.value.replace(/\D/g, "");

    value =
        value.substring(0, 11);

    value =
        value.replace(
            /(\d{3})(\d)/,
            "$1.$2"
        );

    value =
        value.replace(
            /(\d{3})(\d)/,
            "$1.$2"
        );

    value =
        value.replace(
            /(\d{3})(\d{1,2})$/,
            "$1-$2"
        );

    cpf.value = value;

});


// ==========================================
// MÁSCARA TELEFONE
// ==========================================

const telefone =
    document.getElementById("telefone");

telefone.addEventListener(
    "input",
    function () {

        let value =
            telefone.value.replace(/\D/g, "");

        value =
            value.substring(0, 11);

        if (value.length <= 10) {

            value =
                value.replace(
                    /(\d{2})(\d)/,
                    "($1) $2"
                );

            value =
                value.replace(
                    /(\d{4})(\d)/,
                    "$1-$2"
                );

        } else {

            value =
                value.replace(
                    /(\d{2})(\d)/,
                    "($1) $2"
                );

            value =
                value.replace(
                    /(\d{5})(\d)/,
                    "$1-$2"
                );

        }

        telefone.value = value;

    }
);


// ==========================================
// MÁSCARA CEP
// ==========================================

const cep =
    document.getElementById("cep");

cep.addEventListener("input", function () {

    let value =
        cep.value.replace(/\D/g, "");

    value =
        value.substring(0, 8);

    value =
        value.replace(
            /(\d{5})(\d)/,
            "$1-$2"
        );

    cep.value = value;

});


// ==========================================
// ENVIO DO FORMULÁRIO
// ==========================================

form.addEventListener(
    "submit",
    function (event) {

        event.preventDefault();

        const message =
            document.getElementById(
                "formMessage"
            );


        // VALIDAÇÃO DA SENHA

        if (senha.value.length < 8) {

            message.textContent =
                "A senha precisa ter pelo menos 8 caracteres.";

            message.style.color =
                "#c53d3d";

            senha.focus();

            return;

        }


        // CONFIRMAÇÃO DA SENHA

        if (
            senha.value !==
            confirmarSenha.value
        ) {

            message.textContent =
                "As senhas não são iguais.";

            message.style.color =
                "#c53d3d";

            confirmarSenha.focus();

            return;

        }


        // TERMOS

        const termos =
            document.getElementById(
                "termos"
            );

        if (!termos.checked) {

            message.textContent =
                "Você precisa aceitar os Termos de Uso.";

            message.style.color =
                "#c53d3d";

            return;

        }


        // CADASTRO VALIDADO

       message.textContent =
    "Cadastro realizado com sucesso!";

message.style.color =
    "#23733d";

setTimeout(function () {

    window.location.href = "usuario.html";

}, 500);

        message.style.color =
            "#23733d";

    }
);