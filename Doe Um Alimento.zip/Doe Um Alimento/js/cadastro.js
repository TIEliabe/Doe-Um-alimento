// ==========================================
// ELEMENTOS PRINCIPAIS
// ==========================================

const form = document.getElementById("registerForm");

const senha = document.getElementById("senha");
const confirmarSenha = document.getElementById("confirmarSenha");

const strengthBar = document.getElementById("strengthBar");
const passwordMessage = document.getElementById("passwordMessage");
const formMessage = document.getElementById("formMessage");


// ==========================================
// TIPO DE CONTA
// ==========================================

const tipoConta = document.querySelectorAll(
    'input[name="tipoConta"]'
);

const consumerFields =
    document.getElementById("consumerFields");

const companyFields =
    document.getElementById("companyFields");


// ==========================================
// CAMPOS DO CONSUMIDOR
// ==========================================

const nome = document.getElementById("nome");
const cpf = document.getElementById("cpf");
const telefone = document.getElementById("telefone");
const dataNascimento =
    document.getElementById("dataNascimento");


// ==========================================
// CAMPOS DA EMPRESA
// ==========================================

const razaoSocial =
    document.getElementById("razaoSocial");

const nomeFantasia =
    document.getElementById("nomeFantasia");

const cnpj =
    document.getElementById("cnpj");

const telefoneEmpresa =
    document.getElementById("telefoneEmpresa");

const endereco =
    document.getElementById("endereco");

const cep =
    document.getElementById("cep");

const cidade =
    document.getElementById("cidade");

const estado =
    document.getElementById("estado");


// ==========================================
// MOSTRAR CAMPOS DO TIPO DE CONTA
// ==========================================

function atualizarTipoConta() {

    const selecionado = document.querySelector(
        'input[name="tipoConta"]:checked'
    );

    if (!selecionado) {
        return;
    }

    if (selecionado.value === "empresa") {

        // Mostrar empresa
        companyFields.classList.remove("hidden");

        // Esconder consumidor
        consumerFields.classList.add("hidden");


        // Consumidor não obrigatório
        nome.required = false;
        cpf.required = false;


        // Empresa obrigatória
        razaoSocial.required = true;
        nomeFantasia.required = true;
        cnpj.required = true;
        telefoneEmpresa.required = true;
        endereco.required = true;
        cep.required = true;
        cidade.required = true;
        estado.required = true;

    } else {

        // Mostrar consumidor
        consumerFields.classList.remove("hidden");

        // Esconder empresa
        companyFields.classList.add("hidden");


        // Consumidor obrigatório
        nome.required = true;
        cpf.required = true;


        // Empresa não obrigatória
        razaoSocial.required = false;
        nomeFantasia.required = false;
        cnpj.required = false;
        telefoneEmpresa.required = false;
        endereco.required = false;
        cep.required = false;
        cidade.required = false;
        estado.required = false;
    }
}


// ==========================================
// ALTERAÇÃO DO TIPO DE CONTA
// ==========================================

tipoConta.forEach(function (radio) {

    radio.addEventListener(
        "change",
        atualizarTipoConta
    );

});


// Executar ao abrir
atualizarTipoConta();


// ==========================================
// MOSTRAR / ESCONDER SENHA
// ==========================================

const passwordButtons =
    document.querySelectorAll(".show-password");

passwordButtons.forEach(function (button) {

    button.addEventListener(
        "click",
        function () {

            const targetId =
                button.dataset.target;

            const input =
                document.getElementById(targetId);

            if (input.type === "password") {

                input.type = "text";
                button.textContent = "🙈";

            } else {

                input.type = "password";
                button.textContent = "👁";

            }
        }
    );

});


// ==========================================
// FORÇA DA SENHA
// ==========================================

senha.addEventListener(
    "input",
    function () {

        const value = senha.value;

        let strength = 0;

        if (value.length >= 8) {
            strength++;
        }

        if (/[A-Z]/.test(value)) {
            strength++;
        }

        if (/[0-9]/.test(value)) {
            strength++;
        }

        if (/[^A-Za-z0-9]/.test(value)) {
            strength++;
        }


        const widths = [
            "0%",
            "25%",
            "50%",
            "75%",
            "100%"
        ];

        strengthBar.style.width =
            widths[strength];


        if (value.length === 0) {

            passwordMessage.textContent =
                "Use pelo menos 8 caracteres.";

        } else if (strength <= 1) {

            passwordMessage.textContent =
                "Senha fraca.";

        } else if (strength === 2) {

            passwordMessage.textContent =
                "Senha média.";

        } else if (strength === 3) {

            passwordMessage.textContent =
                "Senha boa.";

        } else {

            passwordMessage.textContent =
                "Senha forte.";
        }
    }
);


// ==========================================
// CONFIRMAÇÃO DA SENHA
// ==========================================

confirmarSenha.addEventListener(
    "input",
    verificarSenhas
);

senha.addEventListener(
    "input",
    verificarSenhas
);


function verificarSenhas() {

    const error =
        document.getElementById("senhaError");

    if (
        confirmarSenha.value &&
        confirmarSenha.value !== senha.value
    ) {

        error.textContent =
            "As senhas não são iguais.";

    } else {

        error.textContent = "";
    }
}


// ==========================================
// MÁSCARA CPF
// ==========================================

cpf.addEventListener(
    "input",
    function () {

        let value =
            cpf.value.replace(/\D/g, "");

        value =
            value.substring(0, 11);

        value =
            value.replace(
                /(\d{3})(\d)/,
                "$1.$2"
            );

        value =
            value.replace(
                /(\d{3})(\d)/,
                "$1.$2"
            );

        value =
            value.replace(
                /(\d{3})(\d{1,2})$/,
                "$1-$2"
            );

        cpf.value = value;
    }
);


// ==========================================
// MÁSCARA CNPJ
// ==========================================

cnpj.addEventListener(
    "input",
    function () {

        let value =
            cnpj.value.replace(/\D/g, "");

        value =
            value.substring(0, 14);

        value =
            value.replace(
                /^(\d{2})(\d)/,
                "$1.$2"
            );

        value =
            value.replace(
                /^(\d{2})\.(\d{3})(\d)/,
                "$1.$2.$3"
            );

        value =
            value.replace(
                /\.(\d{3})(\d)/,
                ".$1/$2"
            );

        value =
            value.replace(
                /(\d{4})(\d{1,2})$/,
                "$1-$2"
            );

        cnpj.value = value;
    }
);


// ==========================================
// MÁSCARA TELEFONE CONSUMIDOR
// ==========================================

telefone.addEventListener(
    "input",
    function () {

        telefone.value =
            aplicarMascaraTelefone(
                telefone.value
            );
    }
);


// ==========================================
// MÁSCARA TELEFONE EMPRESA
// ==========================================

telefoneEmpresa.addEventListener(
    "input",
    function () {

        telefoneEmpresa.value =
            aplicarMascaraTelefone(
                telefoneEmpresa.value
            );
    }
);


function aplicarMascaraTelefone(valor) {

    let value =
        valor.replace(/\D/g, "");

    value =
        value.substring(0, 11);

    if (value.length <= 10) {

        value =
            value.replace(
                /(\d{2})(\d)/,
                "($1) $2"
            );

        value =
            value.replace(
                /(\d{4})(\d)/,
                "$1-$2"
            );

    } else {

        value =
            value.replace(
                /(\d{2})(\d)/,
                "($1) $2"
            );

        value =
            value.replace(
                /(\d{5})(\d)/,
                "$1-$2"
            );
    }

    return value;
}


// ==========================================
// MÁSCARA CEP
// ==========================================

cep.addEventListener(
    "input",
    function () {

        let value =
            cep.value.replace(/\D/g, "");

        value =
            value.substring(0, 8);

        value =
            value.replace(
                /(\d{5})(\d)/,
                "$1-$2"
            );

        cep.value = value;
    }
);


// ==========================================
// PEGAR CONTAS
// ==========================================

function pegarContas() {

    const dados =
        localStorage.getItem(
            "contasDoeAlimento"
        );

    if (!dados) {
        return [];
    }

    try {

        const contas =
            JSON.parse(dados);

        return Array.isArray(contas)
            ? contas
            : [];

    } catch (erro) {

        console.error(
            "Erro ao carregar contas:",
            erro
        );

        return [];
    }
}


// ==========================================
// SALVAR CONTAS
// ==========================================

function salvarContas(contas) {

    localStorage.setItem(
        "contasDoeAlimento",
        JSON.stringify(contas)
    );
}


// ==========================================
// ENVIO DO FORMULÁRIO
// ==========================================

form.addEventListener(
    "submit",
    function (event) {

        event.preventDefault();

        formMessage.textContent = "";
        formMessage.style.color = "";


        // ======================================
        // TIPO
        // ======================================

        const tipoSelecionado =
            document.querySelector(
                'input[name="tipoConta"]:checked'
            );

        if (!tipoSelecionado) {

            formMessage.textContent =
                "Selecione o tipo de conta.";

            formMessage.style.color =
                "#c53d3d";

            return;
        }

        const tipo =
            tipoSelecionado.value;


        // ======================================
        // SENHA
        // ======================================

        if (senha.value.length < 8) {

            formMessage.textContent =
                "A senha precisa ter pelo menos 8 caracteres.";

            formMessage.style.color =
                "#c53d3d";

            senha.focus();

            return;
        }


        // ======================================
        // CONFIRMAR SENHA
        // ======================================

        if (
            senha.value !==
            confirmarSenha.value
        ) {

            formMessage.textContent =
                "As senhas não são iguais.";

            formMessage.style.color =
                "#c53d3d";

            confirmarSenha.focus();

            return;
        }


        // ======================================
        // TERMOS
        // ======================================

        const termos =
            document.getElementById("termos");

        if (!termos.checked) {

            formMessage.textContent =
                "Você precisa aceitar os Termos de Uso.";

            formMessage.style.color =
                "#c53d3d";

            return;
        }


        // ======================================
        // E-MAIL
        // ======================================

        const email =
            document.getElementById("email")
                .value
                .trim()
                .toLowerCase();

        if (!email) {

            formMessage.textContent =
                "Informe seu e-mail.";

            formMessage.style.color =
                "#c53d3d";

            return;
        }


        // ======================================
        // CONTAS EXISTENTES
        // ======================================

        const contas =
            pegarContas();


        // ======================================
        // E-MAIL DUPLICADO
        // ======================================

        const emailExiste =
            contas.some(
                function (conta) {

                    return (
                        conta.email &&
                        conta.email.toLowerCase() === email
                    );
                }
            );


        if (emailExiste) {

            formMessage.textContent =
                "Este e-mail já possui uma conta.";

            formMessage.style.color =
                "#c53d3d";

            return;
        }


        // ======================================
        // CONSUMIDOR
        // ======================================

        if (tipo === "consumidor") {

            const consumidor = {

                id:
                    Date.now(),

                tipo:
                    "consumidor",

                status:
                    "aprovado",

                nome:
                    nome.value.trim(),

                cpf:
                    cpf.value.trim(),

                telefone:
                    telefone.value.trim(),

                dataNascimento:
                    dataNascimento.value,

                email:
                    email,

                senha:
                    senha.value,

                criadoEm:
                    new Date().toISOString()
            };


            contas.push(
                consumidor
            );

            salvarContas(
                contas
            );


            formMessage.textContent =
                "Cadastro de consumidor realizado com sucesso!";

            formMessage.style.color =
                "#23733d";


            setTimeout(
                function () {

                    window.location.href =
                        "login.html";

                },
                1000
            );

            return;
        }


        // ======================================
        // EMPRESA
        // ======================================

        if (tipo === "empresa") {

            const empresa = {

                id:
                    Date.now(),

                tipo:
                    "empresa",

                status:
                    "pendente",

                razaoSocial:
                    razaoSocial.value.trim(),

                nomeFantasia:
                    nomeFantasia.value.trim(),

                cnpj:
                    cnpj.value.trim(),

                telefone:
                    telefoneEmpresa.value.trim(),

                endereco:
                    endereco.value.trim(),

                cep:
                    cep.value.trim(),

                cidade:
                    cidade.value.trim(),

                estado:
                    estado.value,

                email:
                    email,

                senha:
                    senha.value,

                criadoEm:
                    new Date().toISOString()
            };


            contas.push(
                empresa
            );

            salvarContas(
                contas
            );


            // Mantém compatibilidade
            // com a estrutura antiga
            localStorage.setItem(
                "empresaPendente",
                JSON.stringify(empresa)
            );


            formMessage.innerHTML =
                "Cadastro enviado com sucesso!<br>" +
                "Sua empresa está <strong>pendente de aprovação</strong> pelo administrador.";


            formMessage.style.color =
                "#765d16";


            return;
        }

    }
);