// =====================================================
// GUAJARÁ VIVE
// JAVASCRIPT DA ÁREA DA EMPRESA
// =====================================================


// =====================================================
// CONFIGURAÇÃO
// =====================================================

const CHAVE_PRODUTOS = "guajaraViveProdutos";


// =====================================================
// ELEMENTOS DA PÁGINA
// =====================================================

const telaProdutos =
    document.getElementById("telaProdutos");

const telaCadastro =
    document.getElementById("telaCadastro");

const tabelaProdutos =
    document.getElementById("tabelaProdutos");

const formProduto =
    document.getElementById("formProduto");

const novoProdutoButton =
    document.getElementById("novoProdutoButton");

const cancelarCadastro =
    document.getElementById("cancelarCadastro");


// =====================================================
// PEGAR PRODUTOS SALVOS
// =====================================================

function pegarProdutos() {

    const produtosSalvos =
        localStorage.getItem(CHAVE_PRODUTOS);


    if (!produtosSalvos) {

        return [];

    }


    try {

        const produtos =
            JSON.parse(produtosSalvos);

        return Array.isArray(produtos)
            ? produtos
            : [];

    } catch (erro) {

        console.error(
            "Erro ao carregar produtos:",
            erro
        );

        return [];

    }

}


// =====================================================
// SALVAR PRODUTOS
// =====================================================

function salvarProdutos(produtos) {

    try {

        localStorage.setItem(
            CHAVE_PRODUTOS,
            JSON.stringify(produtos)
        );

    } catch (erro) {

        console.error(
            "Erro ao salvar produtos:",
            erro
        );

        alert(
            "Não foi possível salvar o produto no navegador."
        );

    }

}


// =====================================================
// ABRIR CADASTRO
// =====================================================

function abrirCadastro() {

    if (!telaProdutos || !telaCadastro) {
        return;
    }

    telaProdutos.style.display = "none";

    telaCadastro.style.display = "block";


    const nomeProduto =
        document.getElementById("nomeProduto");

    if (nomeProduto) {

        nomeProduto.focus();

    }

}


// =====================================================
// VOLTAR PARA PRODUTOS
// =====================================================

function voltarProdutos() {

    if (!telaCadastro || !telaProdutos) {
        return;
    }

    telaCadastro.style.display = "none";

    telaProdutos.style.display = "block";

}


// =====================================================
// MOSTRAR PRODUTOS NA TABELA
// =====================================================

function mostrarProdutos() {

    if (!tabelaProdutos) {
        return;
    }


    tabelaProdutos.innerHTML = "";


    const produtos =
        pegarProdutos();


    // ---------------------------------------------
    // SE NÃO EXISTIR PRODUTO
    // ---------------------------------------------

    if (produtos.length === 0) {

        tabelaProdutos.innerHTML = `

            <tr>

                <td
                    colspan="8"
                    class="sem-produtos"
                >

                    Nenhum produto cadastrado ainda.

                </td>

            </tr>

        `;


        atualizarInformacoes();

        return;

    }


    // ---------------------------------------------
    // CRIAR CADA PRODUTO
    // ---------------------------------------------

    produtos.forEach(function (produto) {

        const linha =
            document.createElement("tr");


        linha.innerHTML = `

            <td>

                <strong>
                    ${escaparHTML(produto.nome)}
                </strong>

            </td>


            <td>
                ${Number(produto.quantidade) || 0}
            </td>


            <td>
                ${escaparHTML(produto.dataFormatada || "")}
            </td>


            <td>
                R$ ${formatarPreco(produto.preco)}
            </td>


            <td>

                <span class="desconto">

                    ${Number(produto.desconto) || 0}%

                </span>

            </td>


            <td>

                <strong class="preco-final">

                    R$ ${formatarPreco(produto.precoFinal)}

                </strong>

            </td>


            <td>

                <span class="status">

                    Disponível

                </span>

            </td>


            <td>

                <button
                    type="button"
                    class="btn-excluir"
                    data-id="${escaparHTML(produto.id)}"
                >

                    Excluir

                </button>

            </td>

        `;


        tabelaProdutos.appendChild(linha);

    });


    atualizarInformacoes();

}


// =====================================================
// CADASTRAR PRODUTO
// =====================================================

function cadastrarProduto(event) {

    event.preventDefault();


    // ---------------------------------------------
    // PEGAR CAMPOS
    // ---------------------------------------------

    const nome =
        document
            .getElementById("nomeProduto")
            .value
            .trim();


    const quantidade =
        Number(
            document
                .getElementById("novaQuantidade")
                .value
        );


    const validade =
        document
            .getElementById("validade")
            .value;


    const preco =
        Number(
            document
                .getElementById("preco")
                .value
        );


    const desconto =
        Number(
            document
                .getElementById("desconto")
                .value
        );


    // ---------------------------------------------
    // VALIDAÇÕES
    // ---------------------------------------------

    if (!nome) {

        alert(
            "Digite o nome do produto."
        );

        return;

    }


    if (
        !Number.isFinite(quantidade) ||
        quantidade <= 0
    ) {

        alert(
            "Digite uma quantidade válida."
        );

        return;

    }


    if (!validade) {

        alert(
            "Informe a data de validade."
        );

        return;

    }


    if (
        !Number.isFinite(preco) ||
        preco <= 0
    ) {

        alert(
            "Digite um preço válido."
        );

        return;

    }


    if (
        !Number.isFinite(desconto) ||
        desconto < 0 ||
        desconto > 90
    ) {

        alert(
            "O desconto deve estar entre 0% e 90%."
        );

        return;

    }


    // ---------------------------------------------
    // CALCULAR PREÇO FINAL
    // ---------------------------------------------

    const precoFinal =
        preco -
        (
            preco *
            desconto /
            100
        );


    // ---------------------------------------------
    // FORMATAR DATA
    // ---------------------------------------------

    const partes =
        validade.split("-");


    const dataFormatada =
        partes.length === 3
            ? `${partes[2]}/${partes[1]}/${partes[0]}`
            : validade;


    // ---------------------------------------------
    // CRIAR NOVO PRODUTO
    // ---------------------------------------------

    const novoProduto = {

        id:
            Date.now().toString()
            +
            Math.random()
                .toString(36)
                .substring(2, 8),

        nome:
            nome,

        quantidade:
            quantidade,

        validade:
            validade,

        dataFormatada:
            dataFormatada,

        preco:
            preco,

        desconto:
            desconto,

        precoFinal:
            precoFinal

    };


    // ---------------------------------------------
    // PEGAR PRODUTOS EXISTENTES
    // ---------------------------------------------

    const produtos =
        pegarProdutos();


    // ---------------------------------------------
    // ADICIONAR PRODUTO
    // ---------------------------------------------

    produtos.push(
        novoProduto
    );


    // ---------------------------------------------
    // SALVAR
    // ---------------------------------------------

    salvarProdutos(
        produtos
    );


    // ---------------------------------------------
    // LIMPAR FORMULÁRIO
    // ---------------------------------------------

    formProduto.reset();


    // ---------------------------------------------
    // ATUALIZAR TABELA
    // ---------------------------------------------

    mostrarProdutos();


    // ---------------------------------------------
    // VOLTAR
    // ---------------------------------------------

    voltarProdutos();


    alert(
        "Produto cadastrado com sucesso!"
    );

}


// =====================================================
// EXCLUIR PRODUTO
// =====================================================

function excluirProduto(id) {

    const confirmar =
        confirm(
            "Deseja realmente excluir este produto?"
        );


    if (!confirmar) {
        return;
    }


    let produtos =
        pegarProdutos();


    produtos =
        produtos.filter(
            function (produto) {

                return produto.id !== id;

            }
        );


    salvarProdutos(
        produtos
    );


    mostrarProdutos();


    alert(
        "Produto excluído com sucesso!"
    );

}


// =====================================================
// ATUALIZAR INFORMAÇÕES
// =====================================================

function atualizarInformacoes() {

    const produtos =
        pegarProdutos();


    // ---------------------------------------------
    // TOTAL DE PRODUTOS
    // ---------------------------------------------

    const total =
        produtos.length;


    // ---------------------------------------------
    // QUANTIDADE TOTAL
    // ---------------------------------------------

    let quantidadeTotal = 0;


    produtos.forEach(
        function (produto) {

            quantidadeTotal +=
                Number(
                    produto.quantidade
                ) || 0;

        }
    );


    // ---------------------------------------------
    // DESCONTO MÉDIO
    // ---------------------------------------------

    let descontoMedio = 0;


    if (total > 0) {

        let somaDescontos = 0;


        produtos.forEach(
            function (produto) {

                somaDescontos +=
                    Number(
                        produto.desconto
                    ) || 0;

            }
        );


        descontoMedio =
            somaDescontos / total;

    }


    // ---------------------------------------------
    // ATUALIZAR QUANTIDADE
    // ---------------------------------------------

    const quantidadeProdutos =
        document.getElementById(
            "quantidadeProdutos"
        );


    if (quantidadeProdutos) {

        quantidadeProdutos.innerText =
            quantidadeTotal;

    }


    // ---------------------------------------------
    // ATUALIZAR DISPONÍVEIS
    // ---------------------------------------------

    const disponiveis =
        document.getElementById(
            "disponiveis"
        );


    if (disponiveis) {

        disponiveis.innerText =
            quantidadeTotal;

    }


    // ---------------------------------------------
    // TOTAL DE PRODUTOS
    // ---------------------------------------------

    const totalProdutos =
        document.getElementById(
            "totalProdutos"
        );


    if (totalProdutos) {

        totalProdutos.innerText =
            total;

    }


    // ---------------------------------------------
    // DESCONTO MÉDIO
    // ---------------------------------------------

    const descontoMedioElemento =
        document.getElementById(
            "descontoMedio"
        );


    if (descontoMedioElemento) {

        descontoMedioElemento.innerText =
            Math.round(
                descontoMedio
            ) + "%";

    }

}


// =====================================================
// FORMATAR PREÇO
// =====================================================

function formatarPreco(valor) {

    const numero =
        Number(valor);


    if (!Number.isFinite(numero)) {

        return "0,00";

    }


    return numero
        .toFixed(2)
        .replace(".", ",");

}


// =====================================================
// SEGURANÇA PARA HTML
// =====================================================

function escaparHTML(texto) {

    const div =
        document.createElement("div");


    div.textContent =
        String(texto ?? "");


    return div.innerHTML;

}


// =====================================================
// EVENTO DO BOTÃO NOVO PRODUTO
// =====================================================

if (novoProdutoButton) {

    novoProdutoButton.addEventListener(
        "click",
        abrirCadastro
    );

}


// =====================================================
// EVENTO DO BOTÃO VOLTAR
// =====================================================

if (cancelarCadastro) {

    cancelarCadastro.addEventListener(
        "click",
        voltarProdutos
    );

}


// =====================================================
// EVENTO DO FORMULÁRIO
// =====================================================

if (formProduto) {

    formProduto.addEventListener(
        "submit",
        cadastrarProduto
    );

}


// =====================================================
// EVENTO DOS BOTÕES DE EXCLUIR
// =====================================================

if (tabelaProdutos) {

    tabelaProdutos.addEventListener(
        "click",
        function (event) {

            const botao =
                event.target.closest(
                    ".btn-excluir"
                );


            if (!botao) {
                return;
            }


            const id =
                botao.dataset.id;


            if (id) {

                excluirProduto(id);

            }

        }
    );

}


// =====================================================
// CARREGAR AO ABRIR A PÁGINA
// =====================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        mostrarProdutos();

    }
);