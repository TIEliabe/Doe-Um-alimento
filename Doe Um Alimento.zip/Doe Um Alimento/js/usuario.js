// ==========================================
// ÁREA DO CONSUMIDOR
// Doe Um Alimento
// ==========================================


// ==========================================
// DADOS DOS ALIMENTOS
// FUTURAMENTE VIRÃO DO PHP + BANCO
// ==========================================

const alimentos = [

    {
        id: 1,
        nome: "Arroz 5kg",
        categoria: "arroz",
        categoriaNome: "Arroz e grãos",
        empresa: "Mercado Bom Preço",
        preco: 18.90,
        precoOriginal: 28.90,
        desconto: 35,
        quantidade: 12,
        validade: "20/08/2026",
        local: "Centro - Guajará-Mirim",
        icone: "🍚"
    },

    {
        id: 2,
        nome: "Pão francês",
        categoria: "paes",
        categoriaNome: "Pães",
        empresa: "Padaria do Bairro",
        preco: 5.00,
        precoOriginal: 8.00,
        desconto: 38,
        quantidade: 25,
        validade: "17/08/2026",
        local: "São José - Guajará-Mirim",
        icone: "🥖"
    },

    {
        id: 3,
        nome: "Banana prata",
        categoria: "frutas",
        categoriaNome: "Frutas",
        empresa: "Hortifruti Central",
        preco: 4.50,
        precoOriginal: 7.00,
        desconto: 36,
        quantidade: 18,
        validade: "18/08/2026",
        local: "Centro - Guajará-Mirim",
        icone: "🍌"
    },

    {
        id: 4,
        nome: "Feijão carioca 1kg",
        categoria: "arroz",
        categoriaNome: "Arroz e grãos",
        empresa: "Supermercado Esperança",
        preco: 6.90,
        precoOriginal: 10.50,
        desconto: 34,
        quantidade: 9,
        validade: "22/08/2026",
        local: "Triângulo - Guajará-Mirim",
        icone: "🫘"
    },

    {
        id: 5,
        nome: "Maçã",
        categoria: "frutas",
        categoriaNome: "Frutas",
        empresa: "Frutaria Guajará",
        preco: 7.90,
        precoOriginal: 12.00,
        desconto: 34,
        quantidade: 15,
        validade: "19/08/2026",
        local: "Centro - Guajará-Mirim",
        icone: "🍎"
    },

    {
        id: 6,
        nome: "Leite integral",
        categoria: "outros",
        categoriaNome: "Outros",
        empresa: "Mercado Econômico",
        preco: 4.99,
        precoOriginal: 7.50,
        desconto: 33,
        quantidade: 20,
        validade: "21/08/2026",
        local: "Comercial - Guajará-Mirim",
        icone: "🥛"
    }

];


// ==========================================
// ELEMENTOS
// ==========================================

const menuButton =
    document.getElementById("menuButton");

const sidebar =
    document.getElementById("sidebar");

const sidebarOverlay =
    document.getElementById("sidebarOverlay");

const notificationButton =
    document.getElementById("notificationButton");

const notificationPanel =
    document.getElementById("notificationPanel");

const closeNotifications =
    document.getElementById("closeNotifications");

const profileButton =
    document.getElementById("profileButton");

const profileMenu =
    document.getElementById("profileMenu");

const foodModal =
    document.getElementById("foodModal");

const closeFoodModal =
    document.getElementById("closeFoodModal");


// ==========================================
// USUÁRIO LOGADO
// ==========================================

function obterUsuarioLogado() {

    const dados =
        localStorage.getItem(
            "usuarioLogado"
        );


    if (!dados) {

        return null;

    }


    try {

        return JSON.parse(dados);

    } catch (erro) {

        console.error(
            "Erro ao carregar usuário:",
            erro
        );

        return null;

    }

}


const usuario =
    obterUsuarioLogado();


// ==========================================
// PROTEGER PÁGINA
// ==========================================

if (!usuario) {

    window.location.href =
        "login.html";

}


// ==========================================
// VERIFICAR TIPO
// ==========================================

if (
    usuario &&
    usuario.tipo !== "consumidor"
) {

    if (usuario.tipo === "empresa") {

        window.location.href =
            "empresa.html";

    }

}


// ==========================================
// DADOS DO USUÁRIO
// ==========================================

function inicializarUsuario() {

    if (!usuario) {
        return;
    }


    const nomeCompleto =
        usuario.nome ||
        "Usuário";


    const primeiroNome =
        nomeCompleto
            .trim()
            .split(" ")[0];


    const iniciais =
        primeiroNome
            .charAt(0)
            .toUpperCase();


    document.getElementById(
        "headerUserName"
    ).textContent =
        primeiroNome;


    document.getElementById(
        "welcomeUserName"
    ).textContent =
        primeiroNome;


    document.getElementById(
        "profileAvatar"
    ).textContent =
        iniciais;


    document.getElementById(
        "profileLargeAvatar"
    ).textContent =
        iniciais;


    document.getElementById(
        "profileMenuAvatar"
    ).textContent =
        iniciais;


    document.getElementById(
        "profileName"
    ).textContent =
        nomeCompleto;


    document.getElementById(
        "profileFullName"
    ).textContent =
        nomeCompleto;


    document.getElementById(
        "profileEmail"
    ).textContent =
        usuario.email || "—";


    document.getElementById(
        "profileMenuName"
    ).textContent =
        primeiroNome;


    document.getElementById(
        "profileMenuEmail"
    ).textContent =
        usuario.email || "—";


    document.getElementById(
        "profileCpf"
    ).textContent =
        usuario.cpf || "—";


    document.getElementById(
        "profilePhone"
    ).textContent =
        usuario.telefone || "—";


    document.getElementById(
        "profileBirth"
    ).textContent =
        formatarData(
            usuario.dataNascimento
        );

}


// ==========================================
// FORMATAR DATA
// ==========================================

function formatarData(data) {

    if (!data) {
        return "—";
    }


    const partes =
        data.split("-");


    if (partes.length !== 3) {
        return data;
    }


    return (
        partes[2] +
        "/" +
        partes[1] +
        "/" +
        partes[0]
    );

}


// ==========================================
// FAVORITOS
// ==========================================

function obterFavoritos() {

    const chave =
        "favoritosDoeAlimento";


    const dados =
        localStorage.getItem(
            chave
        );


    if (!dados) {
        return [];
    }


    try {

        return JSON.parse(dados);

    } catch {

        return [];

    }

}


function salvarFavoritos(favoritos) {

    localStorage.setItem(
        "favoritosDoeAlimento",
        JSON.stringify(favoritos)
    );

}


function ehFavorito(id) {

    return obterFavoritos()
        .includes(id);

}


function alternarFavorito(id) {

    let favoritos =
        obterFavoritos();


    if (favoritos.includes(id)) {

        favoritos =
            favoritos.filter(
                function (item) {

                    return item !== id;

                }
            );

    } else {

        favoritos.push(id);

    }


    salvarFavoritos(
        favoritos
    );


    renderizarAlimentos();
    renderizarFavoritos();
    atualizarEstatisticas();


    if (
        window.alimentoModalAtual &&
        window.alimentoModalAtual.id === id
    ) {

        atualizarBotaoFavoritoModal();

    }

}


// ==========================================
// RESERVAS
// ==========================================

function obterReservas() {

    const dados =
        localStorage.getItem(
            "reservasDoeAlimento"
        );


    if (!dados) {
        return [];
    }


    try {

        return JSON.parse(dados);

    } catch {

        return [];

    }

}


function salvarReservas(reservas) {

    localStorage.setItem(
        "reservasDoeAlimento",
        JSON.stringify(reservas)
    );

}


// ==========================================
// RESERVAR ALIMENTO
// ==========================================

function reservarAlimento(id) {

    const alimento =
        alimentos.find(
            function (item) {

                return item.id === id;

            }
        );


    if (!alimento) {
        return;
    }


    const reservas =
        obterReservas();


    const jaReservado =
        reservas.some(
            function (item) {

                return item.id === id;

            }
        );


    if (jaReservado) {

        alert(
            "Você já reservou este alimento."
        );

        return;

    }


    if (alimento.quantidade <= 0) {

        alert(
            "Este alimento não está mais disponível."
        );

        return;

    }


    const novaReserva = {

        id: alimento.id,

        nome: alimento.nome,

        empresa: alimento.empresa,

        icone: alimento.icone,

        preco: alimento.preco,

        local: alimento.local,

        data:
            new Date()
                .toLocaleDateString("pt-BR"),

        status: "Reservado"

    };


    reservas.push(
        novaReserva
    );


    salvarReservas(
        reservas
    );


    alimento.quantidade--;


    fecharModal();


    atualizarEstatisticas();

    renderizarAlimentos();

    renderizarReservas();

    adicionarNotificacao(
        "Reserva realizada",
        `Você reservou ${alimento.nome}.`,
        "📦"
    );


    alert(
        "Alimento reservado com sucesso! ❤️"
    );

}


// ==========================================
// CANCELAR RESERVA
// ==========================================

function cancelarReserva(id) {

    const confirmar =
        confirm(
            "Deseja realmente cancelar esta reserva?"
        );


    if (!confirmar) {
        return;
    }


    let reservas =
        obterReservas();


    const reserva =
        reservas.find(
            function (item) {

                return item.id === id;

            }
        );


    reservas =
        reservas.filter(
            function (item) {

                return item.id !== id;

            }
        );


    salvarReservas(
        reservas
    );


    const alimento =
        alimentos.find(
            function (item) {

                return item.id === id;

            }
        );


    if (alimento) {

        alimento.quantidade++;

    }


    renderizarReservas();

    renderizarAlimentos();

    atualizarEstatisticas();


    if (reserva) {

        adicionarNotificacao(
            "Reserva cancelada",
            `A reserva de ${reserva.nome} foi cancelada.`,
            "↩️"
        );

    }

}


// ==========================================
// RENDERIZAR ALIMENTOS
// ==========================================

let categoriaAtual = "todos";

let buscaAtual = "";


function obterAlimentosFiltrados() {

    return alimentos.filter(
        function (alimento) {

            const correspondeCategoria =
                categoriaAtual === "todos" ||
                alimento.categoria ===
                categoriaAtual;


            const termo =
                buscaAtual
                    .toLowerCase()
                    .trim();


            const correspondeBusca =
                !termo ||
                alimento.nome
                    .toLowerCase()
                    .includes(termo) ||
                alimento.empresa
                    .toLowerCase()
                    .includes(termo) ||
                alimento.categoriaNome
                    .toLowerCase()
                    .includes(termo);


            return (
                correspondeCategoria &&
                correspondeBusca &&
                alimento.quantidade > 0
            );

        }
    );

}


function criarCardAlimento(alimento) {

    const favorito =
        ehFavorito(
            alimento.id
        );


    return `

        <article
            class="food-card"
            data-food-id="${alimento.id}">

            <div class="food-image">

                <span class="food-discount">
                    ${alimento.desconto}% OFF
                </span>


                <button
                    type="button"
                    class="favorite-button ${favorito ? "active" : ""}"
                    data-favorite="${alimento.id}"
                    aria-label="Favoritar">

                    ${favorito ? "❤️" : "♡"}

                </button>


                <span>
                    ${alimento.icone}
                </span>

            </div>


            <div class="food-content">

                <span class="food-category">
                    ${alimento.categoriaNome}
                </span>


                <h3>
                    ${alimento.nome}
                </h3>


                <p class="food-company">
                    ${alimento.empresa}
                </p>


                <p class="food-location">
                    📍 ${alimento.local}
                </p>


                <div class="food-bottom">

                    <div class="food-price">

                        <strong>
                            ${formatarMoeda(alimento.preco)}
                        </strong>

                        <span class="food-old-price">
                            ${formatarMoeda(alimento.precoOriginal)}
                        </span>

                    </div>


                    <button
                        type="button"
                        class="reserve-button"
                        data-reserve="${alimento.id}">

                        Reservar

                    </button>

                </div>

            </div>

        </article>

    `;

}


function renderizarAlimentos() {

    const grid =
        document.getElementById(
            "foodGrid"
        );


    const alimentosFiltrados =
        obterAlimentosFiltrados();


    grid.innerHTML =
        alimentosFiltrados
            .map(
                criarCardAlimento
            )
            .join("");


    const vazio =
        document.getElementById(
            "foodEmpty"
        );


    vazio.classList.toggle(
        "hidden",
        alimentosFiltrados.length > 0
    );


    adicionarEventosCards();

}


// ==========================================
// TODOS OS ALIMENTOS
// ==========================================

function renderizarTodosAlimentos(
    termo = ""
) {

    const grid =
        document.getElementById(
            "allFoodGrid"
        );


    const resultado =
        alimentos.filter(
            function (alimento) {

                const texto =
                    termo
                        .toLowerCase()
                        .trim();


                return (
                    !texto ||
                    alimento.nome
                        .toLowerCase()
                        .includes(texto) ||
                    alimento.empresa
                        .toLowerCase()
                        .includes(texto) ||
                    alimento.categoriaNome
                        .toLowerCase()
                        .includes(texto)
                );

            }
        );


    grid.innerHTML =
        resultado
            .map(
                criarCardAlimento
            )
            .join("");


    adicionarEventosCards();

}


// ==========================================
// EVENTOS DOS CARDS
// ==========================================

function adicionarEventosCards() {

    document
        .querySelectorAll(
            "[data-favorite]"
        )
        .forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function (event) {

                        event.stopPropagation();

                        alternarFavorito(
                            Number(
                                button.dataset.favorite
                            )
                        );

                    }
                );

            }
        );


    document
        .querySelectorAll(
            "[data-reserve]"
        )
        .forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        reservarAlimento(
                            Number(
                                button.dataset.reserve
                            )
                        );

                    }
                );

            }
        );


    document
        .querySelectorAll(
            ".food-card"
        )
        .forEach(
            function (card) {

                card.addEventListener(
                    "click",
                    function (event) {

                        if (
                            event.target.closest(
                                "button"
                            )
                        ) {

                            return;

                        }


                        abrirModal(
                            Number(
                                card.dataset.foodId
                            )
                        );

                    }
                );

            }
        );

}


// ==========================================
// FAVORITOS
// ==========================================

function renderizarFavoritos() {

    const grid =
        document.getElementById(
            "favoriteGrid"
        );


    const favoritos =
        obterFavoritos();


    const alimentosFavoritos =
        alimentos.filter(
            function (alimento) {

                return favoritos.includes(
                    alimento.id
                );

            }
        );


    grid.innerHTML =
        alimentosFavoritos
            .map(
                criarCardAlimento
            )
            .join("");


    document
        .getElementById(
            "favoriteEmpty"
        )
        .classList.toggle(
            "hidden",
            alimentosFavoritos.length > 0
        );


    adicionarEventosCards();

}


// ==========================================
// RESERVAS
// ==========================================

function renderizarReservas() {

    const list =
        document.getElementById(
            "reservationList"
        );


    const reservas =
        obterReservas();


    list.innerHTML =
        reservas.map(
            function (reserva) {

                return `

                    <article
                        class="reservation-card">

                        <div
                            class="reservation-icon">

                            ${reserva.icone}

                        </div>


                        <div
                            class="reservation-info">

                            <h3>
                                ${reserva.nome}
                            </h3>

                            <p>
                                ${reserva.empresa}
                            </p>

                            <p>
                                📍 ${reserva.local}
                            </p>

                            <p>
                                Reservado em:
                                ${reserva.data}
                            </p>

                        </div>


                        <span
                            class="reservation-status">

                            ${reserva.status}

                        </span>


                        <button
                            type="button"
                            class="cancel-button"
                            data-cancel="${reserva.id}">

                            Cancelar

                        </button>

                    </article>

                `;

            }
        ).join("");


    document
        .getElementById(
            "reservationEmpty"
        )
        .classList.toggle(
            "hidden",
            reservas.length > 0
        );


    document
        .querySelectorAll(
            "[data-cancel]"
        )
        .forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        cancelarReserva(
                            Number(
                                button.dataset.cancel
                            )
                        );

                    }
                );

            }
        );

}


// ==========================================
// ESTATÍSTICAS
// ==========================================

function atualizarEstatisticas() {

    const disponiveis =
        alimentos.reduce(
            function (total, alimento) {

                return (
                    total +
                    alimento.quantidade
                );

            },
            0
        );


    const reservas =
        obterReservas();


    const favoritos =
        obterFavoritos();


    document.getElementById(
        "availableCount"
    ).textContent =
        disponiveis;


    document.getElementById(
        "myReservationCount"
    ).textContent =
        reservas.length;


    document.getElementById(
        "reservationCount"
    ).textContent =
        reservas.length;


    document.getElementById(
        "favoriteCount"
    ).textContent =
        favoritos.length;


    document.getElementById(
        "impactCount"
    ).textContent =
        reservas.length;


    document.getElementById(
        "notificationCount"
    ).textContent =
        contarNotificacoesNaoLidas();


    document.getElementById(
        "notificationCount"
    ).classList.toggle(
        "visible",
        contarNotificacoesNaoLidas() > 0
    );

}


// ==========================================
// MOEDA
// ==========================================

function formatarMoeda(valor) {

    return valor.toLocaleString(
        "pt-BR",
        {
            style: "currency",
            currency: "BRL"
        }
    );

}


// ==========================================
// MODAL
// ==========================================

window.alimentoModalAtual =
    null;


function abrirModal(id) {

    const alimento =
        alimentos.find(
            function (item) {

                return item.id === id;

            }
        );


    if (!alimento) {
        return;
    }


    window.alimentoModalAtual =
        alimento;


    document.getElementById(
        "modalFoodIcon"
    ).textContent =
        alimento.icone;


    document.getElementById(
        "modalFoodCategory"
    ).textContent =
        alimento.categoriaNome;


    document.getElementById(
        "modalFoodName"
    ).textContent =
        alimento.nome;


    document.getElementById(
        "modalFoodCompany"
    ).textContent =
        alimento.empresa;


    document.getElementById(
        "modalFoodPrice"
    ).textContent =
        formatarMoeda(
            alimento.preco
        );


    document.getElementById(
        "modalFoodDiscount"
    ).textContent =
        alimento.desconto + "%";


    document.getElementById(
        "modalFoodQuantity"
    ).textContent =
        alimento.quantidade;


    document.getElementById(
        "modalFoodExpiry"
    ).textContent =
        alimento.validade;


    document.getElementById(
        "modalFoodLocation"
    ).textContent =
        alimento.local;


    atualizarBotaoFavoritoModal();


    foodModal.classList.add(
        "show"
    );

    document.body.style.overflow =
        "hidden";

}


function fecharModal() {

    foodModal.classList.remove(
        "show"
    );

    document.body.style.overflow =
        "";

    window.alimentoModalAtual =
        null;

}


function atualizarBotaoFavoritoModal() {

    const button =
        document.getElementById(
            "modalFavoriteButton"
        );


    if (
        !window.alimentoModalAtual
    ) {
        return;
    }


    const favorito =
        ehFavorito(
            window.alimentoModalAtual.id
        );


    button.textContent =
        favorito
            ? "❤️ Favoritado"
            : "♡ Favoritar";

}


// ==========================================
// EVENTOS DO MODAL
// ==========================================

closeFoodModal.addEventListener(
    "click",
    fecharModal
);


foodModal.addEventListener(
    "click",
    function (event) {

        if (
            event.target ===
            foodModal
        ) {

            fecharModal();

        }

    }
);


document
    .getElementById(
        "modalReserveButton"
    )
    .addEventListener(
        "click",
        function () {

            if (
                window.alimentoModalAtual
            ) {

                reservarAlimento(
                    window.alimentoModalAtual.id
                );

            }

        }
    );


document
    .getElementById(
        "modalFavoriteButton"
    )
    .addEventListener(
        "click",
        function () {

            if (
                window.alimentoModalAtual
            ) {

                alternarFavorito(
                    window.alimentoModalAtual.id
                );

            }

        }
    );


// ==========================================
// NAVEGAÇÃO
// ==========================================

function mostrarSecao(nome) {

    document
        .querySelectorAll(
            ".page-section"
        )
        .forEach(
            function (section) {

                section.classList.remove(
                    "active"
                );

            }
        );


    const section =
        document.getElementById(
            "section-" + nome
        );


    if (!section) {
        return;
    }


    section.classList.add(
        "active"
    );


    document
        .querySelectorAll(
            ".nav-item"
        )
        .forEach(
            function (item) {

                item.classList.toggle(
                    "active",
                    item.dataset.section ===
                    nome
                );

            }
        );


    fecharMenuMobile();

    window.scrollTo(
        {
            top: 0,
            behavior: "smooth"
        }
    );


    if (nome === "alimentos") {

        renderizarTodosAlimentos();

    }


    if (nome === "reservas") {

        renderizarReservas();

    }


    if (nome === "favoritos") {

        renderizarFavoritos();

    }

}


document
    .querySelectorAll(
        ".nav-item"
    )
    .forEach(
        function (item) {

            item.addEventListener(
                "click",
                function (event) {

                    event.preventDefault();

                    mostrarSecao(
                        item.dataset.section
                    );

                }
            );

        }
    );


// ==========================================
// BOTÃO ENCONTRAR ALIMENTOS
// ==========================================

document
    .getElementById(
        "findFoodButton"
    )
    .addEventListener(
        "click",
        function () {

            mostrarSecao(
                "alimentos"
            );

        }
    );


document
    .getElementById(
        "seeAllFoods"
    )
    .addEventListener(
        "click",
        function () {

            mostrarSecao(
                "alimentos"
            );

        }
    );


document
    .getElementById(
        "goFoodsFromReservation"
    )
    .addEventListener(
        "click",
        function () {

            mostrarSecao(
                "alimentos"
            );

        }
    );


// ==========================================
// BUSCA PRINCIPAL
// ==========================================

document
    .getElementById(
        "searchButton"
    )
    .addEventListener(
        "click",
        function () {

            buscaAtual =
                document
                    .getElementById(
                        "searchInput"
                    )
                    .value;


            categoriaAtual =
                "todos";


            document
                .querySelectorAll(
                    ".filter-button"
                )
                .forEach(
                    function (button) {

                        button.classList.toggle(
                            "active",
                            button.dataset.category ===
                            "todos"
                        );

                    }
                );


            renderizarAlimentos();

        }
    );


document
    .getElementById(
        "searchInput"
    )
    .addEventListener(
        "keydown",
        function (event) {

            if (
                event.key ===
                "Enter"
            ) {

                document
                    .getElementById(
                        "searchButton"
                    )
                    .click();

            }

        }
    );


// ==========================================
// FILTROS
// ==========================================

document
    .querySelectorAll(
        ".filter-button"
    )
    .forEach(
        function (button) {

            button.addEventListener(
                "click",
                function () {

                    categoriaAtual =
                        button.dataset.category;


                    buscaAtual =
                        document
                            .getElementById(
                                "searchInput"
                            )
                            .value;


                    document
                        .querySelectorAll(
                            ".filter-button"
                        )
                        .forEach(
                            function (item) {

                                item.classList.remove(
                                    "active"
                                );

                            }
                        );


                    button.classList.add(
                        "active"
                    );


                    renderizarAlimentos();

                }
            );

        }
    );


// ==========================================
// BUSCA NA PÁGINA DE ALIMENTOS
// ==========================================

document
    .getElementById(
        "foodSearchPageButton"
    )
    .addEventListener(
        "click",
        function () {

            const termo =
                document
                    .getElementById(
                        "foodSearchPage"
                    )
                    .value;


            renderizarTodosAlimentos(
                termo
            );

        }
    );


document
    .getElementById(
        "foodSearchPage"
    )
    .addEventListener(
        "keydown",
        function (event) {

            if (
                event.key ===
                "Enter"
            ) {

                document
                    .getElementById(
                        "foodSearchPageButton"
                    )
                    .click();

            }

        }
    );


// ==========================================
// MENU MOBILE
// ==========================================

function abrirMenuMobile() {

    sidebar.classList.add(
        "open"
    );

    sidebarOverlay.classList.add(
        "show"
    );

}


function fecharMenuMobile() {

    sidebar.classList.remove(
        "open"
    );

    sidebarOverlay.classList.remove(
        "show"
    );

}


menuButton.addEventListener(
    "click",
    abrirMenuMobile
);


sidebarOverlay.addEventListener(
    "click",
    fecharMenuMobile
);


// ==========================================
// NOTIFICAÇÕES
// ==========================================

function obterNotificacoes() {

    const dados =
        localStorage.getItem(
            "notificacoesDoeAlimento"
        );


    if (!dados) {

        return [

            {
                id: 1,
                titulo: "Bem-vindo!",
                texto:
                    "Encontre alimentos disponíveis perto de você.",
                icone: "👋",
                lida: false
            }

        ];

    }


    try {

        return JSON.parse(
            dados
        );

    } catch {

        return [];

    }

}


function salvarNotificacoes(
    notificacoes
) {

    localStorage.setItem(
        "notificacoesDoeAlimento",
        JSON.stringify(
            notificacoes
        )
    );

}


function adicionarNotificacao(
    titulo,
    texto,
    icone
) {

    const notificacoes =
        obterNotificacoes();


    notificacoes.unshift(
        {

            id:
                Date.now(),

            titulo:
                titulo,

            texto:
                texto,

            icone:
                icone,

            lida:
                false

        }
    );


    salvarNotificacoes(
        notificacoes
    );


    renderizarNotificacoes();

    atualizarEstatisticas();

}


function contarNotificacoesNaoLidas() {

    return obterNotificacoes()
        .filter(
            function (item) {

                return !item.lida;

            }
        )
        .length;

}


function renderizarNotificacoes() {

    const list =
        document.getElementById(
            "notificationList"
        );


    const notificacoes =
        obterNotificacoes();


    if (!notificacoes.length) {

        list.innerHTML = `

            <div class="empty-state">

                <div>
                    🔔
                </div>

                <h3>
                    Nenhuma notificação
                </h3>

            </div>

        `;

        return;

    }


    list.innerHTML =
        notificacoes.map(
            function (notificacao) {

                return `

                    <div
                        class="notification-item
                        ${notificacao.lida ? "" : "unread"}"
                        data-notification="${notificacao.id}">

                        <div
                            class="notification-item-icon">

                            ${notificacao.icone}

                        </div>


                        <div>

                            <strong>
                                ${notificacao.titulo}
                            </strong>

                            <p>
                                ${notificacao.texto}
                            </p>

                        </div>

                    </div>

                `;

            }
        ).join("");


    document
        .querySelectorAll(
            "[data-notification]"
        )
        .forEach(
            function (item) {

                item.addEventListener(
                    "click",
                    function () {

                        const id =
                            Number(
                                item.dataset.notification
                            );


                        const notificacoes =
                            obterNotificacoes();


                        const notificacao =
                            notificacoes.find(
                                function (item) {

                                    return (
                                        item.id ===
                                        id
                                    );

                                }
                            );


                        if (notificacao) {

                            notificacao.lida =
                                true;

                        }


                        salvarNotificacoes(
                            notificacoes
                        );


                        renderizarNotificacoes();

                        atualizarEstatisticas();

                    }
                );

            }
        );

}


notificationButton.addEventListener(
    "click",
    function (event) {

        event.stopPropagation();

        profileMenu.classList.remove(
            "show"
        );

        notificationPanel.classList.toggle(
            "show"
        );

    }
);


closeNotifications.addEventListener(
    "click",
    function () {

        notificationPanel.classList.remove(
            "show"
        );

    }
);


// ==========================================
// PERFIL MENU
// ==========================================

profileButton.addEventListener(
    "click",
    function (event) {

        event.stopPropagation();

        notificationPanel.classList.remove(
            "show"
        );

        profileMenu.classList.toggle(
            "show"
        );

    }
);


document
    .querySelectorAll(
        "[data-profile-action]"
    )
    .forEach(
        function (button) {

            button.addEventListener(
                "click",
                function () {

                    profileMenu.classList.remove(
                        "show"
                    );


                    mostrarSecao(
                        button.dataset.profileAction
                    );

                }
            );

        }
    );


document.addEventListener(
    "click",
    function (event) {

        if (
            !profileMenu.contains(
                event.target
            ) &&
            !profileButton.contains(
                event.target
            )
        ) {

            profileMenu.classList.remove(
                "show"
            );

        }


        if (
            !notificationPanel.contains(
                event.target
            ) &&
            !notificationButton.contains(
                event.target
            )
        ) {

            notificationPanel.classList.remove(
                "show"
            );

        }

    }
);


// ==========================================
// DOAÇÃO
// ==========================================

document
    .getElementById(
        "donateButton"
    )
    .addEventListener(
        "click",
        function () {

            alert(
                "A área de doações será conectada ao sistema de doações quando o PHP e o banco de dados forem adicionados."
            );

        }
    );


// ==========================================
// CONFIGURAÇÕES
// ==========================================

document
    .getElementById(
        "notificationSetting"
    )
    .addEventListener(
        "change",
        function () {

            localStorage.setItem(
                "notificacoesAtivas",
                this.checked
            );

        }
    );


document
    .getElementById(
        "confirmCancelSetting"
    )
    .addEventListener(
        "change",
        function () {

            localStorage.setItem(
                "confirmarCancelamento",
                this.checked
            );

        }
    );


// ==========================================
// LOGOUT
// ==========================================

function sairDaConta() {

    const confirmar =
        confirm(
            "Deseja realmente sair da sua conta?"
        );


    if (!confirmar) {
        return;
    }


    localStorage.removeItem(
        "usuarioLogado"
    );


    window.location.href =
        "login.html";

}


document
    .getElementById(
        "logoutButton"
    )
    .addEventListener(
        "click",
        sairDaConta
    );


document
    .getElementById(
        "settingsLogout"
    )
    .addEventListener(
        "click",
        sairDaConta
    );


document
    .getElementById(
        "profileLogout"
    )
    .addEventListener(
        "click",
        sairDaConta
    );


// ==========================================
// INICIALIZAÇÃO
// ==========================================

function iniciarPagina() {

    if (!usuario) {
        return;
    }


    inicializarUsuario();

    renderizarAlimentos();

    renderizarTodosAlimentos();

    renderizarReservas();

    renderizarFavoritos();

    renderizarNotificacoes();

    atualizarEstatisticas();


    const notificacoesAtivas =
        localStorage.getItem(
            "notificacoesAtivas"
        );


    if (
        notificacoesAtivas !== null
    ) {

        document.getElementById(
            "notificationSetting"
        ).checked =
            notificacoesAtivas === "true";

    }


    const confirmarCancelamento =
        localStorage.getItem(
            "confirmarCancelamento"
        );


    if (
        confirmarCancelamento !== null
    ) {

        document.getElementById(
            "confirmCancelSetting"
        ).checked =
            confirmarCancelamento === "true";

    }

}


iniciarPagina();