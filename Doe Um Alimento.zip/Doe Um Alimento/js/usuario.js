// ===============================
// BOTÃO SAIR
// ===============================

const logoutButton =
    document.getElementById("logoutButton");

logoutButton.addEventListener("click", function () {

    const confirmar =
        confirm("Deseja realmente sair da sua conta?");

    if (confirmar) {

        window.location.href = "login.html";

    }

});


// ===============================
// BUSCA DE ALIMENTOS
// ===============================

const searchButton =
    document.getElementById("searchButton");

const searchInput =
    document.getElementById("searchInput");


searchButton.addEventListener("click", function () {

    const busca =
        searchInput.value.trim();

    if (busca === "") {

        alert("Digite o nome de um alimento.");

        return;

    }

    alert(
        "Buscando por: " + busca
    );

});


// ===============================
// RESERVAR ALIMENTO
// ===============================

const reserveButtons =
    document.querySelectorAll(".reserve-button");


reserveButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        alert(
            "Alimento reservado com sucesso! ❤️"
        );

    });

});