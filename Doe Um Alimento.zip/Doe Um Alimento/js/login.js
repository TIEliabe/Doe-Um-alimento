const loginForm =
    document.getElementById("loginForm");

const senha =
    document.getElementById("senha");

const showPassword =
    document.getElementById("showPassword");


// ===============================
// MOSTRAR / ESCONDER SENHA
// ===============================

showPassword.addEventListener(
    "click",
    function () {

        if (senha.type === "password") {

            senha.type = "text";

            showPassword.textContent = "🙈";

        } else {

            senha.type = "password";

            showPassword.textContent = "👁";

        }

    }
);


// ===============================
// LOGIN
// ===============================

loginForm.addEventListener(
    "submit",
    function (event) {

        event.preventDefault();


        const email =
            document.getElementById("email").value;

        const senhaValue =
            senha.value;

        const message =
            document.getElementById(
                "loginMessage"
            );


        if (!email || !senhaValue) {

            message.textContent =
                "Preencha seu e-mail e sua senha.";

            message.style.color =
                "#c53d3d";

            return;

        }


        /*
         * FUTURO:
         *
         * Aqui vamos conectar o login
         * ao backend e ao banco de dados.
         */


        message.textContent = "Login realizado!";

message.style.color = "#23733d";

setTimeout(function () {
    window.location.href = "usuario.html";
}, 500);

        message.style.color =
            "#23733d";

    }
);