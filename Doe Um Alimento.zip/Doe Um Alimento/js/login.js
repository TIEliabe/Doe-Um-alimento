// ==========================================
// ELEMENTOS
// ==========================================

const loginForm =
    document.getElementById("loginForm");

const senha =
    document.getElementById("senha");

const showPassword =
    document.getElementById("showPassword");

const loginMessage =
    document.getElementById("loginMessage");


// ==========================================
// MOSTRAR / ESCONDER SENHA
// ==========================================

if (showPassword && senha) {

    showPassword.addEventListener(
        "click",
        function () {

            if (senha.type === "password") {

                senha.type = "text";

                showPassword.textContent =
                    "🙈";

            } else {

                senha.type = "password";

                showPassword.textContent =
                    "👁";
            }

        }
    );
}


// ==========================================
// PEGAR CONTAS
// ==========================================

function pegarContas() {

    const dados =
        localStorage.getItem(
            "contasDoeAlimento"
        );

    if (!dados) {
        return [];
    }

    try {

        const contas =
            JSON.parse(dados);

        return Array.isArray(contas)
            ? contas
            : [];

    } catch (erro) {

        console.error(
            "Erro ao carregar contas:",
            erro
        );

        return [];
    }
}


// ==========================================
// LOGIN
// ==========================================

if (loginForm) {

    loginForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            loginMessage.textContent =
                "";

            loginMessage.style.color =
                "";


            // ==================================
            // DADOS
            // ==================================

            const email =
                document.getElementById(
                    "email"
                )
                .value
                .trim()
                .toLowerCase();


            const senhaValue =
                senha.value.trim();


            // ==================================
            // VALIDAR
            // ==================================

            if (
                email === "" ||
                senhaValue === ""
            ) {

                loginMessage.textContent =
                    "Preencha seu e-mail e sua senha.";

                loginMessage.style.color =
                    "#c53d3d";

                return;
            }


            // ==================================
            // PEGAR CONTAS
            // ==================================

            const contas =
                pegarContas();


            // ==================================
            // PROCURAR CONTA
            // ==================================

            const conta =
                contas.find(
                    function (item) {

                        return (
                            item.email &&
                            item.email.toLowerCase() === email
                        );

                    }
                );


            // ==================================
            // CONTA NÃO EXISTE
            // ==================================

            if (!conta) {

                loginMessage.textContent =
                    "E-mail ou senha incorretos.";

                loginMessage.style.color =
                    "#c53d3d";

                return;
            }


            // ==================================
            // SENHA INCORRETA
            // ==================================

            if (
                conta.senha !==
                senhaValue
            ) {

                loginMessage.textContent =
                    "E-mail ou senha incorretos.";

                loginMessage.style.color =
                    "#c53d3d";

                return;
            }


            // ==================================
            // CONSUMIDOR
            // ==================================

            if (
                conta.tipo ===
                "consumidor"
            ) {

                // Criar sessão
                localStorage.setItem(
                    "usuarioLogado",
                    JSON.stringify(conta)
                );


                loginMessage.textContent =
                    "Login realizado! Entrando na sua conta...";

                loginMessage.style.color =
                    "#23733d";


                setTimeout(
                    function () {

                        window.location.href =
                            "usuario.html";

                    },
                    700
                );


                return;
            }


            // ==================================
            // EMPRESA
            // ==================================

            if (
                conta.tipo ===
                "empresa"
            ) {


                // ==================================
                // EMPRESA PENDENTE
                // ==================================

                if (
                    conta.status ===
                    "pendente"
                ) {

                    loginMessage.innerHTML =
                        "Sua empresa ainda está " +
                        "<strong>pendente de aprovação</strong> " +
                        "pelo administrador.";

                    loginMessage.style.color =
                        "#765d16";

                    return;
                }


                // ==================================
                // EMPRESA APROVADA
                // ==================================

                if (
                    conta.status ===
                    "aprovada"
                ) {

                    // Criar sessão da empresa
                    localStorage.setItem(
                        "empresaLogada",
                        JSON.stringify(conta)
                    );


                    loginMessage.textContent =
                        "Login realizado! Entrando no painel da empresa...";

                    loginMessage.style.color =
                        "#23733d";


                    setTimeout(
                        function () {

                            window.location.href =
                                "empresa.html";

                        },
                        700
                    );


                    return;
                }


                // ==================================
                // OUTRO STATUS
                // ==================================

                loginMessage.textContent =
                    "Sua conta não está disponível para acesso.";

                loginMessage.style.color =
                    "#c53d3d";

                return;
            }


            // ==================================
            // TIPO INVÁLIDO
            // ==================================

            loginMessage.textContent =
                "Tipo de conta inválido.";

            loginMessage.style.color =
                "#c53d3d";

        }
    );

}