<?php

session_start();

require_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Acesso inválido.");
}

$email = trim($_POST["email"] ?? "");
$senha = $_POST["senha"] ?? "";

if (empty($email) || empty($senha)) {
    die("Informe o e-mail e a senha.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("E-mail inválido.");
}

try {

    // Primeiro procura entre os usuários
    $sql = $conexao->prepare(
        "SELECT id, nome, email, senha
         FROM usuarios
         WHERE email = :email
         LIMIT 1"
    );

    $sql->execute([
        ":email" => $email
    ]);

    $usuario = $sql->fetch();

    if ($usuario && password_verify($senha, $usuario["senha"])) {

        session_regenerate_id(true);

        $_SESSION["usuario_id"] = $usuario["id"];
        $_SESSION["usuario_nome"] = $usuario["nome"];
        $_SESSION["usuario_email"] = $usuario["email"];
        $_SESSION["tipo"] = "usuario";

        header("Location: ../paginas/usuario.html");
        exit;
    }


    // Se não encontrou usuário, procura empresa
    $sql = $conexao->prepare(
        "SELECT id, nome, email, senha, status
         FROM empresas
         WHERE email = :email
         LIMIT 1"
    );

    $sql->execute([
        ":email" => $email
    ]);

    $empresa = $sql->fetch();

    if ($empresa && password_verify($senha, $empresa["senha"])) {

        if ($empresa["status"] !== "aprovada") {

            die(
                "Sua empresa ainda não foi aprovada pelo administrador."
            );
        }

        session_regenerate_id(true);

        $_SESSION["empresa_id"] = $empresa["id"];
        $_SESSION["empresa_nome"] = $empresa["nome"];
        $_SESSION["empresa_email"] = $empresa["email"];
        $_SESSION["tipo"] = "empresa";

        header("Location: ../paginas/empresa.html");
        exit;
    }


    die("E-mail ou senha incorretos.");

} catch (PDOException $erro) {

    die("Erro ao realizar o login.");

}

?>