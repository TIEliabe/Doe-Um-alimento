<?php

require_once "conexao.php";

header("Content-Type: application/json; charset=UTF-8");

try {

    // Pessoas cadastradas
    $sql = $conexao->query(
        "SELECT COUNT(*) FROM usuarios"
    );

    $usuarios = (int) $sql->fetchColumn();


    // Empresas aprovadas
    $sql = $conexao->query(
        "SELECT COUNT(*)
         FROM empresas
         WHERE status = 'aprovada'"
    );

    $empresas = (int) $sql->fetchColumn();


    // Alimentos aproveitados
    $sql = $conexao->query(
        "SELECT COUNT(*)
         FROM alimentos
         WHERE status = 'aproveitado'"
    );

    $alimentos = (int) $sql->fetchColumn();


    // Peso total dos alimentos aproveitados
    $sql = $conexao->query(
        "SELECT COALESCE(SUM(peso), 0)
         FROM alimentos
         WHERE status = 'aproveitado'"
    );

    $peso = (float) $sql->fetchColumn();


    echo json_encode([
        "sucesso" => true,
        "usuarios" => $usuarios,
        "empresas" => $empresas,
        "alimentos" => $alimentos,
        "peso" => $peso
    ]);

} catch (PDOException $erro) {

    http_response_code(500);

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro ao buscar estatísticas."
    ]);

}

?>