<?php

require_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Acesso inválido.");
}

$tipo = $_POST["tipo"] ?? "";
$nome = trim($_POST["nome"] ?? "");
$email = trim($_POST["email"] ?? "");
$senha = $_POST["senha"] ?? "";

if (empty($tipo) || empty($nome) || empty($email) || empty($senha)) {
    die("Preencha todos os campos obrigatórios.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("E-mail inválido.");
}

if (strlen($senha) < 8) {
    die("A senha deve ter pelo menos 8 caracteres.");
}

$senhaHash = password_hash(
    $senha,
    PASSWORD_DEFAULT
);

try {

    if ($tipo === "usuario") {

        $cpf = trim($_POST["cpf"] ?? "");

        if (empty($cpf)) {
            die("Informe o CPF.");
        }

        $verificar = $conexao->prepare(
            "SELECT id FROM usuarios
             WHERE email = :email OR cpf = :cpf
             LIMIT 1"
        );

        $verificar->execute([
            ":email" => $email,
            ":cpf" => $cpf
        ]);

        if ($verificar->fetch()) {
            die("E-mail ou CPF já cadastrado.");
        }

        $sql = $conexao->prepare(
            "INSERT INTO usuarios
            (nome, cpf, email, senha)
            VALUES
            (:nome, :cpf, :email, :senha)"
        );

        $sql->execute([
            ":nome" => $nome,
            ":cpf" => $cpf,
            ":email" => $email,
            ":senha" => $senhaHash
        ]);

        header("Location: ../paginas/login.html?cadastro=sucesso");
        exit;
    }


    if ($tipo === "empresa") {

        $cnpj = trim($_POST["cnpj"] ?? "");
        $telefone = trim($_POST["telefone"] ?? "");
        $endereco = trim($_POST["endereco"] ?? "");

        if (
            empty($cnpj) ||
            empty($telefone) ||
            empty($endereco)
        ) {
            die("Preencha todos os dados da empresa.");
        }

        $verificar = $conexao->prepare(
            "SELECT id FROM empresas
             WHERE email = :email OR cnpj = :cnpj
             LIMIT 1"
        );

        $verificar->execute([
            ":email" => $email,
            ":cnpj" => $cnpj
        ]);

        if ($verificar->fetch()) {
            die("E-mail ou CNPJ já cadastrado.");
        }

        $sql = $conexao->prepare(
            "INSERT INTO empresas
            (nome, cnpj, endereco, telefone, email, senha, status)
            VALUES
            (:nome, :cnpj, :endereco, :telefone, :email, :senha, 'pendente')"
        );

        $sql->execute([
            ":nome" => $nome,
            ":cnpj" => $cnpj,
            ":endereco" => $endereco,
            ":telefone" => $telefone,
            ":email" => $email,
            ":senha" => $senhaHash
        ]);

        header("Location: ../paginas/login.html?cadastro=empresa_pendente");
        exit;
    }

    die("Tipo de cadastro inválido.");

} catch (PDOException $erro) {

    die("Erro ao realizar o cadastro.");

}

?>
